#!/bin/sh

git clone --depth=1 --branch=cord-5.0 https://github.com/opencord/quagga.git
