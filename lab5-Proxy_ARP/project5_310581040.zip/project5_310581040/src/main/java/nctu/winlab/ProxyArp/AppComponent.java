/*
 * Copyright 2023-present Open Networking Foundation
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package nctu.winlab.ProxyArp;

import org.onosproject.cfg.ComponentConfigService;
import org.osgi.service.component.ComponentContext;
import org.osgi.service.component.annotations.Activate;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Deactivate;
import org.osgi.service.component.annotations.Modified;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.component.annotations.ReferenceCardinality;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Dictionary;
import java.util.Properties;

import static org.onlab.util.Tools.get;

import java.util.HashMap;
import java.util.Arrays;
import java.nio.ByteBuffer;

import org.onosproject.net.ConnectPoint;
import org.onosproject.net.DeviceId;
import org.onosproject.net.PortNumber;
import org.onlab.packet.Ethernet;
import org.onlab.packet.MacAddress;
import org.onlab.packet.Ip4Address;
import org.onlab.packet.ARP;

import org.onosproject.core.ApplicationId;
import org.onosproject.core.CoreService;
import org.onosproject.net.packet.PacketService;

import org.onosproject.net.packet.PacketPriority;
import org.onosproject.net.packet.PacketContext;
//import org.onosproject.net.packet.InboundPacket;
import org.onosproject.net.packet.PacketProcessor;
import org.onosproject.net.packet.InboundPacket;
import org.onosproject.net.packet.DefaultOutboundPacket;
import org.onosproject.net.packet.OutboundPacket;

import org.onosproject.net.flow.DefaultTrafficSelector;
import org.onosproject.net.flow.DefaultTrafficTreatment;
//import org.onosproject.net.flow.FlowRule;
//import org.onosproject.net.flow.DefaultFlowRule;

import org.onosproject.net.flow.TrafficSelector;
import org.onosproject.net.flow.TrafficTreatment;
import org.onosproject.net.flowobjective.DefaultForwardingObjective;
import org.onosproject.net.flowobjective.FlowObjectiveService;
import org.onosproject.net.flowobjective.ForwardingObjective;

/**
 * Skeletal ONOS application component.
 */
@Component(immediate = true,
           service = {SomeInterface.class},
           property = {
               "someProperty=Some Default String Value",
           })
public class AppComponent implements SomeInterface {

    private final Logger log = LoggerFactory.getLogger(getClass());

    /** Some configurable property. */
    private String someProperty;

    protected HashMap<Ip4Address, MacAddress> ipMacTable = new HashMap<>();
    protected HashMap<Ip4Address, PortNumber> ipPortTable = new HashMap<>();
    protected HashMap<Ip4Address, DeviceId> ipDeviceTable = new HashMap<>();

    private ProxyArpProcessor arpProcessor = new ProxyArpProcessor();
    private ApplicationId appId;

    @Reference(cardinality = ReferenceCardinality.MANDATORY)
    protected ComponentConfigService cfgService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY)
    protected CoreService coreService;

    @Reference(cardinality = ReferenceCardinality.MANDATORY)
    protected PacketService packetService;

    @Activate
    protected void activate() {
        appId = coreService.registerApplication("nctu.winlab.ProxyArp");
        packetService.addProcessor(arpProcessor, PacketProcessor.director(2));
        // ARP Packet in request
        packetService.requestPackets(
            DefaultTrafficSelector.builder().matchEthType(Ethernet.TYPE_ARP).build(),
            PacketPriority.REACTIVE, appId
        );
        log.info("Started");
    }

    @Deactivate
    protected void deactivate() {
        packetService.removeProcessor(arpProcessor);
        log.info("Stopped");
    }

    @Modified
    public void modified(ComponentContext context) {
        Dictionary<?, ?> properties = context != null ? context.getProperties() : new Properties();
        if (context != null) {
            someProperty = get(properties, "someProperty");
        }
        log.info("Reconfigured");
    }

    @Override
    public void someMethod() {
        log.info("Invoked");
    }

    private class ProxyArpProcessor implements PacketProcessor {
        @Override
        public void process(PacketContext context) {
            if (context.isHandled()) {
                return;
            }
            //Represents a data packet intercepted from an infrastructure device.
            //InboundPacket   pkt = context.inPacket();
            Ethernet        ethPkt      = context.inPacket().parsed();
            ConnectPoint    cp          = context.inPacket().receivedFrom();
            DeviceId        deviceID    = cp.deviceId();
            PortNumber      inPort      = cp.port();


            if (ethPkt.getEtherType() != Ethernet.TYPE_ARP) {
                return;
            }
            ARP arpPacket = (ARP) ethPkt.getPayload();
            MacAddress senderMAC    = new MacAddress(arpPacket.getSenderHardwareAddress());
            Ip4Address senderIP     = Ip4Address.valueOf(arpPacket.getSenderProtocolAddress());
            MacAddress targetMAC    = new MacAddress(arpPacket.getTargetHardwareAddress());
            Ip4Address targetIP     = Ip4Address.valueOf(arpPacket.getTargetProtocolAddress());

            ipMacTable.putIfAbsent(senderIP , senderMAC);
            ipPortTable.putIfAbsent(senderIP, inPort);
            ipDeviceTable.putIfAbsent(senderIP, deviceID);

            
            if (arpPacket.getOpCode() == ARP.OP_RARP_REQUEST || arpPacket.getOpCode() == ARP.OP_REQUEST) {
                //Check Sender is in the MAC Table
                arpRequestPacket(context, senderIP, targetIP);
                //log.info("[Sender] H1 MAC `{}`, H1 IP `{}`", ipMacTable.get(senderIP).toString(), senderIP.toString());
                //log.info("H2 MAC `{}`, H2 IP `{}`", arrayToMacString(arpPacket.getTargetHardwareAddress()), arpPacket.getTargetProtocolAddress());
            }

            if (arpPacket.getOpCode() == ARP.OP_RARP_REPLY || arpPacket.getOpCode() == ARP.OP_REPLY) {
                log.info("RECV REPLY. Requested MAC = {}", senderMAC.toString());
                if (ipMacTable.containsKey(targetIP)) {
                    //log.info("[Target] H1 MAC `{}`, H1 IP `{}`", ipMacTable.get(targetIP).toString(), targetIP.toString());
                    Ethernet frame = buildArpPacket(ARP.OP_REPLY, senderIP, targetIP);
                    sendFrame(ipDeviceTable.get(targetIP), ipPortTable.get(targetIP), frame);
                    //context.treatmentBuilder().setIpDst(targetIP);
                    //context.send();
                }
            }
        }

        
        public void arpRequestPacket(PacketContext context, Ip4Address senderIP, Ip4Address targetIP) {

            ConnectPoint    cp          = context.inPacket().receivedFrom();
            DeviceId        deviceID    = cp.deviceId();
            PortNumber      inPort      = cp.port();

            //////PACKET OUT
            //[MISS] Destination MAC Not Exist -> FLOOD
            if (!ipMacTable.containsKey(targetIP)) {

                PortNumber outPort = PortNumber.FLOOD;
                context.treatmentBuilder().setOutput(outPort);
                //Triggers the outbound packet to be sent.
                context.send();
                log.info("TABLE MISS. Send request to edge ports");
                return;
            }
            //[HIT] Destination MAC is exist
            else{
                Ethernet frame = buildArpPacket(ARP.OP_REPLY, targetIP, senderIP);
                sendFrame(deviceID, inPort, frame);
                log.info("TABLE HIT. Requested MAC = {}", ipMacTable.get(targetIP).toString());
            }

            return;
        }

        public Ethernet buildArpPacket(short op, Ip4Address senderIP, Ip4Address targetIP){ 
            ARP arp = new ARP();
            arp.setOpCode(op);
            arp.setProtocolType(ARP.PROTO_TYPE_IP);
            arp.setHardwareType(ARP.HW_TYPE_ETHERNET);
            arp.setProtocolAddressLength((byte) Ip4Address.BYTE_LENGTH);
            arp.setHardwareAddressLength((byte) Ethernet.DATALAYER_ADDRESS_LENGTH);         
            arp.setSenderHardwareAddress(ipMacTable.get(senderIP).toBytes());
            arp.setSenderProtocolAddress(senderIP.toInt());
            arp.setTargetHardwareAddress(ipMacTable.get(targetIP).toBytes());
            arp.setTargetProtocolAddress(targetIP.toInt());
            
            Ethernet eth = new Ethernet();
            eth.setDestinationMACAddress(ipMacTable.get(targetIP));
            eth.setSourceMACAddress(ipMacTable.get(senderIP));
            eth.setEtherType(Ethernet.TYPE_ARP);
            eth.setPayload(arp);

            return eth;
        }

        public void sendFrame(DeviceId deviceID, PortNumber outPort, Ethernet frame){
            TrafficTreatment treatment = DefaultTrafficTreatment.builder().setOutput(outPort).build();
            OutboundPacket outPacket = new DefaultOutboundPacket(deviceID, treatment, ByteBuffer.wrap(frame.serialize()));
            packetService.emit(outPacket);
        }

    }


}
