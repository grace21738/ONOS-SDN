#!/bin/bash
mvn clean install -DskipTests
onos-app localhost deactivate nctu.winlab.ProxyArp
onos-app localhost uninstall nctu.winlab.ProxyArp
onos-app localhost install! target/ProxyArp-1.0-SNAPSHOT.oar